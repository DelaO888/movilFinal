package com.example.blessflag.ui.eliminar;

import androidx.lifecycle.ViewModel;

public class EliminarViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}