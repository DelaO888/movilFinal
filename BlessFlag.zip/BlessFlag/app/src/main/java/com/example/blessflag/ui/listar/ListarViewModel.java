package com.example.blessflag.ui.listar;

import androidx.lifecycle.ViewModel;

public class ListarViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}