package com.example.blessflag.ui.editar;

import androidx.lifecycle.ViewModel;

public class EditarViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}