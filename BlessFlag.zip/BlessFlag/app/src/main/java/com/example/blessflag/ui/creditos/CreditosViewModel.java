package com.example.blessflag.ui.creditos;

import androidx.lifecycle.ViewModel;

public class CreditosViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}