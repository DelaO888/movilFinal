package com.example.blessflag.ui.create;

import androidx.lifecycle.ViewModel;

public class CreateViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}